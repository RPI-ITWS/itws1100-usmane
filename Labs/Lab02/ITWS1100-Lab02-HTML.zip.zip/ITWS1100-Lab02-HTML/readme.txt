ITWS Lab 02

My thoughts:
    I really enjoyed this lab overall. Organizing a resume was something
    I had on my to do list for a while. This was way better and turned out
    much better than I had imagined. I'm pretty excited to be sharing this 
    around at the career fair and hopefully it opens up some doors.

What I learned:
    I learned a lot about HTML, CSS, Github, and how websites are created in general. 
    I didn't think I could do something like this in a couple days. I never even thought
    that coding your resume was an option. I usually would go to resume builders and just
    fill out a template.

My struggles:
    I struggled at first with the syntax of HTML. After about an hour of coding with my friends for
    this lab it became a lot easier. I still struggle with making better blocks of code. I wanted
    the texts to be grouped but couldnt figure out how to group and align them all together without 
    doing a complete shift to how I wrote this code. So, the main struggles were alignment and also
    fitting everything on one page. I don't think it'll fit inside one page but I added a scroll option.
    I will figure out how I'll alter my resume so it can fit on one page. Another issue I have is that
    when I want to print the website page it only shows the first part of what is displayed rather than
    showing everything as like a document. I don't really know how to fix it because I think that isn't
    an issue with my code but an issue with my scroll add on.